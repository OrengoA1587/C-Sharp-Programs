﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* Date 02.17.2020
* CSC 153
* Anthony Orengo
* Program description: This program determines the distance of a free
* falling object by the amount of time the object took to fall.
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Call method 
            FreeFall.FreeFallCalculator();
            
        }//end of main 

    }//End of class Program

}//End of namespace
