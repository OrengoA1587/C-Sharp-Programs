﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;
namespace ConsoleUI
{
    public class DisplayAverageAge
    {
        public static void EmployeeAverageAge(List<Employee> employeeInfo)
        {
           

        }
    }
}
